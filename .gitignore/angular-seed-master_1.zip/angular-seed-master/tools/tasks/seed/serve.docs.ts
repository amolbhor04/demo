// import { serveDocs } from '../../utils';
//
// /**
//  * Executes the build process, serving the application documentation using an `express` server.
//  */
// export = serveDocs;

